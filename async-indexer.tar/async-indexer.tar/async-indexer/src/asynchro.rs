use futures::stream::{self, StreamExt};
use rss::Channel;
use scraper::{Html, Selector};
use std::fs::File;
use std::io::BufReader;
use url::Url;

use crate::common::*;

const MAX_CONN: usize = 59;

/// Open the file and use the `rss` crate to read the file and get a list of `Item`s (namely,
/// feeds). For each feed in the list, get the URL and call `process_feed`. Take a look at the
/// examples in the `rss` crate.
pub async fn process_feed_file(file_name: &str) -> RssIndexResult<ArticleIndex> {
    todo!()
}

/// Read a feed file from a URL, build an rss channel from it, and iterate through the `Item`s
/// (articles). Pull out three pieces of information: the URL, the hostname, and the title (see
/// `Item::link`, `Url::parse`, and `Url::host_str` here). Process each url/title with
/// `process_article`, and then add it to the input `ArticleIndex` along with the hostname. If an
/// `Item` is missing a url/hostname/title, skip it (do not panic).
async fn process_feed(url: &str) -> RssIndexResult<Vec<(String, String, String, Bag<String>)>> {
    todo!()
}

/// Delimiters for splitting a string
const DELIMS: &str = " \t\r\n!@#$%^&*()_-+=~`{[}]|\\\"':;<,>.?/";

/// Use `reqwest` to fetch the article URL, use `scraper` to parse the document, select the "body"
/// tag, and get the text, split each string on `DELIMS` (see `std::string::split` and
/// `std::string::contains`), convert each piece to lowercase, and return a vector of words
/// appearing in the article (possibly with duplicates).
async fn process_article(url: &str) -> RssIndexResult<Bag<String>> {
    todo!()
}
