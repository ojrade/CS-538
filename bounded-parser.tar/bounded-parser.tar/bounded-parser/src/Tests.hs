module Tests where

import Calc

import Control.Applicative (Alternative, liftA2)
import Test.QuickCheck

--
--
-- Tests
--
--


checkEq :: (Eq a, Show a) => a -> a -> String
checkEq got expected
    | expected == got = "PASS"
    | otherwise       = "FAIL Expected: " ++ show expected ++ " Got: " ++ show got

-- These are just basic tests: we do not guarantee that they cover everything!
-- You can add your own tests here.

{-

testEval :: IO ()
testEval = do
  putStr "Plus: "
  putStrLn $ checkEq (eval (Plus (NumC 1) (NumC 1))) (Right $ NumC 2)

  putStr "Ifte: "
  putStrLn $ checkEq (eval (Ifte (BoolC True) (NumC 1) (NumC 2))) (Right $ NumC 1)

  putStr "And: "
  putStrLn $ checkEq (eval (And (BoolC True) (BoolC False))) (Right $ BoolC False)

  putStr "IsEq: "
  putStrLn $ checkEq (eval (IsEq (Plus (NumC 2) (NumC 2)) (NumC 5))) (Right $ BoolC False)

  putStr "List: "
  putStrLn $ checkEq (eval (List [Plus (NumC 1) (NumC 1), Plus (NumC 1) (NumC 1)])) (Right $ List [NumC 2, NumC 2])

  putStr "Car: "
  putStrLn $ checkEq (eval (Car $ List [NumC 2, NumC 2])) (Right $ NumC 2)
  
  putStr "Cdr: "
  putStrLn $ checkEq (eval (Cdr $ List [NumC 2, NumC 2])) (Right $ List [NumC 2])

  putStr "App: "
  putStrLn $ checkEq (eval (App (Lam (Plus (Var 1) (NumC 1))) (NumC 1))) (Right $ NumC 2)

testParse :: IO ()
testParse = do
  putStr "Num: "
  putStrLn $ checkEq (parseTest (parseRExpr Map.empty) "42") (Just $ NumC 42)

  putStr "Bool: "
  putStrLn $ checkEq (parseTest (parseRExpr Map.empty) "#t") (Just $ BoolC True)

  putStr "Plus: "
  putStrLn $ checkEq (parseTest (parseRExpr Map.empty) "(+ 1 1)") (Just $ Plus (NumC 1) (NumC 1))

  putStr "Ifte: "
  putStrLn $ checkEq (parseTest (parseRExpr Map.empty) "(if #t 1 2)") (Just $ Ifte (BoolC True) (NumC 1) (NumC 2))

  putStr "And: "
  putStrLn $ checkEq (parseTest (parseRExpr Map.empty) "(and #t #f)") (Just $ And (BoolC True) (BoolC False))

  putStr "List: "
  putStrLn $ checkEq (parseTest (parseRExpr Map.empty) "(list 1 2)") (Just $ List [NumC 1, NumC 2])

  putStr "Lam1: "
  putStrLn $ checkEq (parseTest (parseRExpr Map.empty) "(lambda x x)") (Just $ Lam (Var 1))

  putStr "Lam2: "
  putStrLn $ checkEq (parseTest (parseRExpr Map.empty) "(lambda x (lambda x x))") (Just $ Lam $ Lam (Var 1))

  putStr "Lam3: "
  putStrLn $ checkEq (parseTest (parseRExpr Map.empty) "(lambda x (lambda y x))") (Just $ Lam $ Lam (Var 2))

  putStr "App: "
  putStrLn $ checkEq (parseTest (parseRExpr Map.empty) "((lambda x x) 1)") (Just $ App (Lam (Var 1)) (NumC 1))

  putStr "Def: "
  putStrLn $ checkEq (parseTest (parseRExpr Map.empty) "(define x (lambda y x))") (Just $ Rec $ Lam (Var 2))

-}

--
--
-- Expression generator
--
-- For more advanced tests, we can randomly generate expressions. Here, we set
-- up a QuickCheck generator for `CExpr`. You can use this generator with
-- QuickCheck properties to do property-based testing of your parser (see the
-- properties below).
--
-- To run the QuickCheck tests, use `cabal v2-repl` and then type `:l
-- Tests` to load the module. Then, you can do
--
-- `quickCheck printParse`
--
-- to run each test 100 times.
--
--

-- This controls the size of terms produced (don't turn it up too high!)
genSize :: Int
genSize = 5

--
--
-- An expression generator
--
--

genCExpr :: Int -> Gen CExpr
genCExpr d = MkCExpr <$> (genCFact d) <*> (genCExprR d)

genCExprR :: Int -> Gen CExprR
genCExprR 0 = pure EndExpr
genCExprR d = oneof [ pure EndExpr
                    , Add <$> (genCFact (d - 1)) <*> (genCExprR (d - 1))
                    , Sub <$> (genCFact (d - 1)) <*> (genCExprR (d - 1))
                    ]

genCFact :: Int -> Gen CFact
genCFact d = MkCFact <$> (genCTerm d) <*> (genCFactR d)

genCFactR :: Int -> Gen CFactR
genCFactR 0 = pure EndFact
genCFactR d = oneof [ pure EndFact
                    , Mul <$> (genCTerm (d - 1)) <*> (genCFactR (d - 1))
                    , Mod <$> (genCTerm (d - 1)) <*> (genCFactR (d - 1))
                    ]

genCTerm :: Int -> Gen CTerm
genCTerm 0 = Num <$> choose(0, 20)
genCTerm d = oneof [ Num <$> choose(0,20)
                   , Parens <$> (genCExpr (d - 1))
                   ]

--
--
-- Quickcheck property: pretty-print/parse
--
--

printParse :: Property
printParse = forAll (genCExpr genSize)
  (\e -> Consumed (ParseOk e "") == runParser parseCExpr (tokenize . ppCExpr $ e))
