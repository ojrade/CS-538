module Ruse.Eval where

import Ruse.Syntax

--
--
-- Big-step evaluator
--
-- Given an RExpr, evaluate it to either Right of an RExpr representing the
-- final value, or Left of a String representing a runtime error. Use the error
-- strings that have been provided; you shouldn't need any other runtime errors.
--
-- You should not try to detect if the original RExpr represents a
-- non-terminating program---your evaluator should simply loop in that case.
--
-- When evaluating an RExpr with multiple components (for instance, `Plus`), you
-- should try to evaluate the components in order. If any component returns an
-- error (Left _), your evaluator should return this error (rather than changing
-- the error). Note, however, that some constructs are lazy (And, Or, If, Cond).
-- The big-step semantics document describes how these things should be
-- evaluated.
--
--
eval :: RExpr -> Either String RExpr
eval e = case e of
           NumC i -> return $ NumC i
           BoolC b -> return $ BoolC b
           StrC s -> return $ StrC s
           Var i -> return $ Var i
           Lam e1 -> return $ Lam e1
           Plus e1 e2 -> evalPlus e1 e2
           Subt e1 e2 -> evalSubt e1 e2
           Mult e1 e2 -> evalMult e1 e2
           Ifte e0 e1 e2 -> evalIfte e0 e1 e2
           And e1 e2 -> evalAnd e1 e2
           Or e1 e2 -> evalOr e1 e2
           Not e1 -> evalNot e1
           IsEq e1 e2 -> evalIsEq e1 e2
           IsLt e1 e2 -> evalIsLt e1 e2
           IsGt e1 e2 -> evalIsGt e1 e2
           IsNil e1 -> evalIsNil e1
           List le -> evalList le
           Cons e1 e2 -> evalCons e1 e2
           Car e -> evalCar e
           Cdr e -> evalCdr e
           App e1 e2 -> evalApp e1 e2
           e -> return $ e

-- We've done Plus for you, but the code is very ugly. Start by cleaning up this
-- function using do-notation. You should be able to eliminate the first two
-- case analyses.
evalPlus :: RExpr -> RExpr -> Either String RExpr
evalPlus e1 e2 = do e1' <- eval e1  
                    e2' <- eval e2
                    case (e1',e2') of
                      (NumC i1, NumC i2) -> return $ NumC (i1 + i2)
                      _ -> Left "Add on non-numeric"

evalSubt :: RExpr -> RExpr -> Either String RExpr
evalSubt e1 e2 = do e1' <- eval e1
                    e2' <- eval e2
                    case (e1',e2') of
                      (NumC i1, NumC i2) -> return $ NumC (i1 - i2)
                      _ -> Left "Sub on non-numeric"

evalMult :: RExpr -> RExpr -> Either String RExpr
evalMult e1 e2 = do e1' <- eval e1
                    e2' <- eval e2
                    case (e1',e2') of
                      (NumC i1, NumC i2) -> return $ NumC (i1 + i2)
                      _ -> Left "Mult on non-numeric"

evalIfte :: RExpr -> RExpr -> RExpr -> Either String RExpr
evalIfte e e1 e2 = do e' <- eval e
                      e1' <- eval e1
                      e2' <- eval e2
                      case e' of
                        (BoolC b) -> if (b == True)
                                       then return e1'
                                       else return e2'
                        _ -> Left "If-then-else guard not Boolean"

evalAnd :: RExpr -> RExpr -> Either String RExpr
evalAnd e1 e2 = do e1' <- eval e1
                   e2' <- eval e2
                   case (e1',e2') of
                     (BoolC b1, BoolC b2) -> return $ BoolC (b1 && b2)
                     _ -> Left "And on non-Boolean"

evalOr :: RExpr -> RExpr -> Either String RExpr
evalOr e1 e2 =  do e1' <- eval e1
                   e2' <- eval e2
                   case (e1',e2') of
                     (BoolC b1, BoolC b2) -> return $ BoolC (b1 || b2)
                     _ -> Left "Or on non-Boolean"

evalNot :: RExpr -> Either String RExpr
evalNot e =  do e' <- eval e
                case e' of
                  (BoolC b) -> return $ BoolC (not b)
                  _ -> Left "Not on non-Boolean"

evalIsEq :: RExpr -> RExpr -> Either String RExpr
evalIsEq e1 e2 = do e1' <- eval e1
                    e2' <- eval e2
                    case (e1',e2') of
                      (NumC i1, NumC i2) -> return $ BoolC (i1 == i2)
                      _ -> Left "Equality on non-numeric"

evalIsLt :: RExpr -> RExpr -> Either String RExpr
evalIsLt e1 e2 = do e1' <- eval e1
                    e2' <- eval e2
                    case (e1',e2') of
                      (NumC i1, NumC i2) -> return $ BoolC (i1 < i2)
                      _ -> Left "Lt on non-numeric"

evalIsGt :: RExpr -> RExpr -> Either String RExpr
evalIsGt e1 e2 = do e1' <- eval e1
                    e2' <- eval e2
                    case (e1',e2') of
                      (NumC i1, NumC i2) -> return $ BoolC (i1 > i2)
                      _ -> Left "Gt on non-numeric"

evalIsNil :: RExpr -> Either String RExpr
evalIsNil e = do e' <- eval e
                 case e' of
                   (List l) -> if (null l)
                                 then return $ BoolC True
                                 else return $ BoolC False
                   _ -> Left "IsNil on non-list"

evalList :: [RExpr] -> Either String RExpr
evalList [] = return $ List []
evalList (e:es) = do e' <- eval e
                     case es of
                       [] -> return $ List [e']
                       l -> do es' <- eval (List l)
                               case es' of
                                 (List l1) -> return $ (List (e':l1))

evalCons :: RExpr -> RExpr -> Either String RExpr
evalCons e1 e2 = do e1' <- eval e1
                    e2' <- eval e2
                    case (e1',e2') of
                      (e,List l) -> return $ (List (e:l))
                      _ -> Left "Cons on non-list"

evalCar :: RExpr -> Either String RExpr
evalCar e = case e of
              (List []) -> Left "Car of empty list"
              (List (l:ls)) -> do h' <- eval l
                                  return $ h' 
              _ -> Left "Car of non-list"

evalCdr :: RExpr -> Either String RExpr
evalCdr e = case e of
              (List []) -> Left "Cdr of empty list"
              (List (l:ls)) -> do h' <- evalList ls
                                  return $ h'
              _ -> Left "Cdr of non-list"

evalApp :: RExpr -> RExpr -> Either String RExpr
evalApp e1 e2 = do e1' <- eval e1
                   e2' <- eval e2 
                   case e1' of
                     (Lam f) -> do e' <- eval (subst e2' f)
                                   return $ e'
                     _ -> Left "Apply non-function"

evalRec :: RExpr -> Either String RExpr
evalRec e = do e' <- eval e
               case (e') of
                 (Rec f) -> eval (subst e f)
                 _ -> Left "Rec non-rec"
