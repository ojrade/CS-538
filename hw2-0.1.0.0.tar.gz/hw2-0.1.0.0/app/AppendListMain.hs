import AppendList

main :: IO ()
main = tests
